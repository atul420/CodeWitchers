
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import Header from './Header';

const Login = () => {

    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const navigate = useNavigate();

    const loginForm = async(e) => {
        e.preventDefault();
        try{
            console.log("Login with ",email,password);
            
            const res = await axios.post('http://localhost:3000/api/users/loginUser', {
                email,
                password
            });
            console.log('Login success:', res.data);
            // Store token in localStorage
            if (res.data && res.data.token) {
                localStorage.setItem('token', res.data.token);
            }
            // Redirect to menu page
            navigate('/menu');

        }
        catch(err){
            console.error('Login error:', err);
            alert('Login failed. Please try again.');
        }
    }

  return (
    <div className='w-screen min-h-screen max-w-none bg-emerald-800 flex flex-col items-center justify-center'>
      <Header />
      <div className='bg-white rounded-xl shadow-lg px-10 py-12 flex flex-col items-center w-full max-w-md mt-32'>
        <h2 className='text-3xl font-bold text-center mb-4 text-emerald-800'>Login Page</h2>
        <p className='text-lg text-center mb-8 text-gray-700'>Please enter your credentials to log in.</p>
        <form onSubmit={loginForm} className='w-full flex flex-col items-center'>
          <input
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            type="email"
            placeholder="Email"
            className='border border-gray-300 p-3 w-full rounded-lg mb-4 focus:outline-none focus:ring-2 focus:ring-emerald-400'
          />
          <div className='w-full relative mb-6'>
            <input
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              type={showPassword ? 'text' : 'password'}
              placeholder="Password"
              className='border border-gray-300 p-3 w-full rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-400'
              style={{ paddingRight: '3rem' }}
            />
            <button
              type="button"
              className='absolute right-3 top-1/2 -translate-y-1/2 text-emerald-700 text-sm font-semibold focus:outline-none'
              onClick={() => setShowPassword((prev) => !prev)}
              tabIndex={-1}
            >
              {showPassword ? 'Hide' : 'Show'}
            </button>
          </div>
          <button className='bg-emerald-600 text-white w-full py-3 rounded-lg font-semibold hover:bg-emerald-700 transition mb-4'>Login</button>
        </form>
        <div className='flex flex-row gap-4 mt-2'>
          <Link to="/signup" className='text-lg bg-slate-400 font-bold text-white cursor-pointer px-4 py-2 ml-2 mr-2 rounded-lg hover:bg-slate-500 transition'>Sign Up</Link>
          <Link to="/" className='text-lg bg-slate-400 font-bold text-white cursor-pointer px-4 py-2 ml-2 mr-2 rounded-lg hover:bg-slate-500 transition'>Home</Link>
        </div>
      </div>
    </div>
  )
}

export default Login
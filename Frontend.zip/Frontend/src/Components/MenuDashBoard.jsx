import React from 'react';
import { Link, useLocation } from 'react-router-dom';

const menuItems = [
  { label: 'Home', path: '/menu' },
  { label: 'Events', path: '/events' },
  { label: 'Bookings', path: '/bookings' },
  { label: 'Payments', path: '/payments' },
  { label: 'User Profile', path: '/userProfile' },
];

const MenuDashBoard = () => {
  const location = useLocation();
  return (
    <div className="w-full flex flex-col items-center" style={{ marginTop: '120px' }}>
      <div className="w-full flex justify-center">
        <div className="bg-white rounded-xl shadow-lg px-8 py-6 flex flex-col items-center w-full" style={{ borderRadius: '0.75rem' }}>
          <h1 className="text-2xl font-extrabold text-emerald-800 mb-4 tracking-wide text-center">Menu</h1>
          <hr className="w-full border-emerald-200 mb-4" />
          <nav className="flex flex-row gap-6 justify-center w-full mb-2">
            {menuItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`text-base font-bold px-4 py-2 rounded-lg border border-emerald-200 shadow-sm transition hover:bg-emerald-100 ${location.pathname === item.path ? 'bg-emerald-100 text-emerald-900' : 'text-emerald-700'}`}
              >
                {item.label}
              </Link>
            ))}
          </nav>
        </div>
      </div>
    </div>
  );
};

export default MenuDashBoard;

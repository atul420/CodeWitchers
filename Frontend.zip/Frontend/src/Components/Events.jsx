import React, { useEffect, useState } from 'react';
import EventCard from './EventCard';
import axios from 'axios';

const Events = () => {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const token = localStorage.getItem('token');
    axios.get('http://localhost:3000/api/events', {
      headers: {
        Authorization: `Bearer ${token}`
      }
    })
      .then(res => {
        setEvents(Array.isArray(res.data) ? res.data : []);
        setLoading(false);
      })
      .catch(err => {
        setError('Failed to load events');
        console.log(err);
        setLoading(false);
      });
  }, []);

  if (loading) return <div className="text-white text-xl mt-10">Loading events...</div>;
  if (error) return <div className="text-red-500 text-xl mt-10">{error}</div>;

  return (
    <div className="flex flex-col items-center w-full mt-8">
      <h2 className="text-3xl font-extrabold text-emerald-800 mb-6 text-center">All Events</h2>
      {events.length === 0 ? (
        <div className="text-gray-700 text-lg">No events found.</div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-3 gap-8 w-full justify-items-center">
          {events.map(event => (
            <EventCard key={event.id || event.title} event={event} />
          ))}
        </div>
      )}
    </div>
  );
};

export default Events;

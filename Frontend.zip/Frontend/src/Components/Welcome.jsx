import React from 'react';

const Welcome = () => (
  <div className="flex flex-col items-center justify-center w-full mt-8">
    <div className="bg-white rounded-xl shadow-lg px-10 py-12 flex flex-col items-center w-full max-w-md">
      <h2 className="text-3xl font-extrabold text-emerald-800 mb-4 text-center">Welcome to GoGather Event Booking Site</h2>
      <p className="text-lg text-center text-gray-700">Your one-stop solution for all your event and gathering needs.</p>
    </div>
  </div>
);

export default Welcome;

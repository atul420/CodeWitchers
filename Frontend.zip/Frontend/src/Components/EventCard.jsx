import React from 'react';

// Props: event = { id, title, description, date, time, price, capacity, category, createdBy, createdAt }
const EventCard = ({ event }) => {
  if (!event) return null;

  return (
    <div className="bg-white rounded-xl shadow-lg p-8 w-full max-w-lg mx-auto my-6 border border-emerald-200">
      <h2 className="text-3xl font-bold text-emerald-800 mb-2">{event.title}</h2>
      <div className="text-gray-600 mb-4 text-sm">Event ID: {event.id}</div>
      <div className="mb-3 text-gray-700">
        <span className="font-semibold">Category:</span> {event.category}
      </div>
      <div className="mb-3 text-gray-700">
        <span className="font-semibold">Date:</span> {event.date ? new Date(event.date).toLocaleDateString() : '-'}
        {event.time && (
          <span> &bull; <span className="font-semibold">Time:</span> {event.time}</span>
        )}
      </div>
      <div className="mb-3 text-gray-700">
        <span className="font-semibold">Price:</span> ${event.price}
        <span className="ml-4 font-semibold">Capacity:</span> {event.capacity}
      </div>
      <div className="mb-3 text-gray-700">
        <span className="font-semibold">Created By (User ID):</span> {event.createdBy}
      </div>
      <div className="mb-3 text-gray-700">
        <span className="font-semibold">Created At:</span> {event.createdAt ? new Date(event.createdAt).toLocaleString() : '-'}
      </div>
      {event.description && (
        <div className="mt-4 text-gray-800">
          <span className="font-semibold">Description:</span>
          <div className="whitespace-pre-line mt-1">{event.description}</div>
        </div>
      )}
    </div>
  );
};

export default EventCard;

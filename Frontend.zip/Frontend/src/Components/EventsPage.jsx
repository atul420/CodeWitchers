import React from 'react';
import Header from './Header';
import MenuDashBoard from './MenuDashBoard';
import Events from './Events';

const EventsPage = () => {
  return (
    <div className="w-screen min-h-screen max-w-none bg-emerald-800 flex flex-col items-center justify-start">
      <Header />
      <MenuDashBoard />
      <div className="flex-grow w-full max-w-4xl px-4 py-8 mx-auto">
        <Events />
      </div>
    </div>
  );
};

export default EventsPage;

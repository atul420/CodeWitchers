import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const UserProfile = () => {

    const token = localStorage.getItem('token');
    const [response, setResponse] = useState(null);
    const navigate = useNavigate();

    useEffect(() => {
        if (!token) {
            navigate('/login');
            return;
        }
        const fetchData = async () => {
            try {
                const result = await axios.get('http://localhost:3000/api/users/getUser', {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                });
                setResponse(result.data);
            } catch (err) {
                console.error('Error fetching user profile:', err);
                // Optionally handle error, e.g., navigate('/login')
            }
        };
        fetchData();
    }, [token, navigate]);

    return (
      <div className='w-screen min-h-screen max-w-none bg-emerald-800 flex flex-col items-center justify-center'>
        <div className='bg-white rounded-xl shadow-lg px-10 py-12 flex flex-col items-center w-full max-w-md'>
          <h2 className='text-3xl font-bold text-center mb-4 text-emerald-800'>User Profile</h2>
          {response ? (
            <div className='w-full'>
              <div className='mb-4'><span className='font-semibold'>Username:</span> {response.username}</div>
              <div className='mb-4'><span className='font-semibold'>Email:</span> {response.email}</div>
              <div className='mb-4'><span className='font-semibold'>Role:</span> {response.role}</div>
              <div className='mb-4'><span className='font-semibold'>User ID:</span> {response.id}</div>
              <button
                className='mt-8 bg-red-500 text-white px-6 py-2 rounded-lg font-semibold hover:bg-red-600 transition w-full'
                onClick={() => {
                  localStorage.removeItem('token');
                  navigate('/login');
                }}
              >
                Logout
              </button>
            </div>
          ) : (
            <div className='text-gray-500'>Loading profile...</div>
          )}
        </div>
      </div>
    )
}

export default UserProfile
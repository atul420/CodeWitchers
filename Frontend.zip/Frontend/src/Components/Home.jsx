import React from 'react'
import { Link } from 'react-router-dom';
import Header from './Header';

const Home = () => {
  return (
    <div className='w-screen min-h-screen max-w-none bg-emerald-800 flex flex-col items-center justify-center'>
      <Header />
      <div className='bg-white rounded-xl shadow-lg px-10 py-12 flex flex-col items-center w-full max-w-md mt-32'>
        <h1 className='text-4xl font-extrabold text-emerald-800 mb-2 tracking-wide text-center'>Welcome to GoGather</h1>
        <p className='text-lg text-center mb-8 text-gray-700'>Your one-stop solution for all your gathering needs.</p>
        <div className='flex flex-row gap-4 mt-2'>
          <Link to="/login" className='text-lg bg-slate-400 font-bold text-white cursor-pointer px-4 py-2 rounded-lg hover:bg-slate-500 transition'>Login</Link>
          <Link to="/signup" className='text-lg bg-slate-400 font-bold text-white cursor-pointer px-4 py-2 rounded-lg hover:bg-slate-500 transition'>Sign Up</Link>
        </div>
      </div>
    </div>
  )
}

export default Home
import React from 'react';

const Header = () => (
  <div className='fixed top-0 left-0 w-full bg-emerald-900 py-6 shadow-md overflow-hidden z-50' style={{ minWidth: '100vw' }}>
    <div className='animate-slide-brand whitespace-nowrap' style={{ width: '100vw' }}>
      <span className='text-7xl font-extrabold text-white tracking-widest pl-4'>GoGather</span>
    </div>
    <style>{`
      @keyframes slide-brand {
        0% { transform: translateX(-100%); }
        100% { transform: translateX(100vw); }
      }
      .animate-slide-brand {
        animation: slide-brand 8s linear infinite;
      }
    `}</style>
  </div>
);

export default Header;

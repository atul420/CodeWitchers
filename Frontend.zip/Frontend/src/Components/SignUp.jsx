import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';

const SignUp = () => {
    const [username, setUsername] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [showSuccess, setShowSuccess] = useState(false);
    const navigate = useNavigate();

    const signUpForm = async (e) => {
        e.preventDefault();
        try {
            const res = await axios.post('http://localhost:3000/api/users/registerUser', {
                username,
                email,
                password
            });
            console.log('Signup success:', res.data);
            setShowSuccess(true);
            setTimeout(() => {
                setShowSuccess(false);
                navigate('/login');
            }, 2000);
        } catch (err) {
            console.error('Signup error:', err);
            alert('Signup failed. Please try again.');
        }
    }
  return (
    <div className='w-screen min-h-screen max-w-none bg-emerald-800 flex flex-col items-center justify-center'>
      {showSuccess && (
        <div className='fixed top-8 left-1/2 -translate-x-1/2 bg-green-500 text-white px-8 py-4 rounded-lg shadow-lg z-50 text-xl font-semibold'>
          Signup Successful!
        </div>
      )}
      <div className='bg-white rounded-xl shadow-lg px-10 py-12 flex flex-col items-center w-full max-w-md'>
        <h2 className='text-3xl font-bold text-center mb-4 text-emerald-800'>Sign Up Page</h2>
        <p className='text-lg text-center mb-8 text-gray-700'>Create your account to start using GoGather.</p>
        <form className='w-full flex flex-col items-center' onSubmit={signUpForm}>
          <input onChange={(e) => setUsername(e.target.value)} type="text" placeholder="Username" className='border border-gray-300 p-3 w-full rounded-lg mb-4 focus:outline-none focus:ring-2 focus:ring-emerald-400' />
          <input onChange={(e) => setEmail(e.target.value)} type="email" placeholder="Email" className='border border-gray-300 p-3 w-full rounded-lg mb-4 focus:outline-none focus:ring-2 focus:ring-emerald-400' />
          <div className='w-full relative mb-6'>
            <input
              onChange={(e) => setPassword(e.target.value)}
              type={showPassword ? 'text' : 'password'}
              placeholder="Password"
              className='border border-gray-300 p-3 w-full rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-400'
              style={{ paddingRight: '3rem' }}
            />
            <button
              type="button"
              className='absolute right-3 top-1/2 -translate-y-1/2 text-emerald-700 text-sm font-semibold focus:outline-none'
              onClick={() => setShowPassword((prev) => !prev)}
              tabIndex={-1}
            >
              {showPassword ? 'Hide' : 'Show'}
            </button>
          </div>
          <button type="submit" className='bg-emerald-600 text-white w-full py-3 rounded-lg font-semibold hover:bg-emerald-700 transition mb-4'>Sign Up</button>
        </form>
        <div className='flex flex-row gap-4 mt-2'>
          <Link to="/login" className='text-lg bg-slate-400 font-bold text-white cursor-pointer px-4 py-2 rounded-lg hover:bg-slate-500 transition'>Login</Link>
          <Link to="/" className='text-lg bg-slate-400 font-bold text-white cursor-pointer px-4 py-2 rounded-lg hover:bg-slate-500 transition'>Home</Link>
        </div>
      </div>
    </div>
  )
}

export default SignUp
import React from 'react';
import Header from './Header';
import MenuDashBoard from './MenuDashBoard';
import Welcome from './Welcome';

const Menu = () => {
  return (
    <div className="w-screen min-h-screen max-w-none bg-emerald-800 flex flex-col items-center justify-start">
      <Header />
      <MenuDashBoard />
      <Welcome />
    </div>
  );
};

export default Menu;

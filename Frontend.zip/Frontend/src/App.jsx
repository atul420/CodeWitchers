
import React from 'react';
import Home from './Components/Home';
import { Routes, Route } from 'react-router-dom';
import Login from './Components/Login';
import SignUp from './Components/SignUp';
import UserProfile from './Components/UserProfile';
import Menu from './Components/Menu';
import EventsPage from './Components/EventsPage';

const App = () => {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/login" element={<Login />} />
      <Route path='/signup' element={<SignUp />} />
      <Route path="/userProfile" element={<UserProfile />} />
      <Route path="/menu" element={<Menu />} />
      <Route path="/events" element={<EventsPage />} />
    </Routes>
  )
}

export default App
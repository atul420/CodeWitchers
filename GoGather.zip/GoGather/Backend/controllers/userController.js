const Users = require('../models').Users;
const bcrypt = require('bcryptjs');
const generateToken = require('../utils/generateToken');
const users = require('../models/users');

exports.registerUser = async (req, res) => {
  const { username, email, password } = req.body;

  try {

    const existingUser = await Users.findOne({ where: { email } });
    if (existingUser) {
      return res.status(400).json({ message: 'User with this email already exists' });
    }
    if (!username || !email || !password) {
      return res.status(400).json({ message: 'All fields are required' });
    }
    if (password.length < 6) {
      return res.status(400).json({ message: 'Password must be at least 6 characters long' });
    }
    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = await Users.create({ username, email, password: hashedPassword });
    res.status(201).json({ message: 'User registered successfully', user: newUser });

  } catch (error) {
    console.error('Error registering user:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
}

exports.listUsers = async (req, res) => {
  try {
    const users = await Users.findAll();
    res.status(200).json(users);
  } catch (error) {
    console.error('Error fetching users:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
}

exports.loginUser = async (req, res) => {
  const { email, password } = req.body;

  try {
    //check user exists
    const user = await Users.findOne({ where: { email} });
    console.log(user);
    if (!user) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    //match password
    if (await bcrypt.compare(password, user.password)) {
      return res.status(401).json({ message: 'Wrong password' });
    }

    const token = generateToken(user.id, user.role);

    res.status(200).json(
      { 
        message: 'Login successful', 
        user, 
        token 
      });
  } catch (error) {
    console.error('Error logging in user:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
}

exports.getUserProfile = async (req, res) => {
  const userId = req.user.id;

  try {
    const user = await Users.findByPk(userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    //check for token
    const token = req.headers['authorization']?.split(' ')[1];
    if (!token) {
      return res.status(401).json({ message: 'Unauthorized' });
    }
    //verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    if (!decoded) {
      return res.status(401).json({ message: 'Unauthorized' });
    }
    req.user = decoded;
    res.status(200).json(user);
  } catch (error) {
    console.error('Error fetching user profile:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
}

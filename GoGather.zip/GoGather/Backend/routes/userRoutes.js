const express = require('express');
const { registerUser,listUsers, loginUser,getUserProfile} = require('../controllers/userController');
const router = express.Router();

router.post('/registerUser', registerUser);
router.get('/listUsers',listUsers)
router.post('/loginUser', loginUser);
router.get('/getUser/:id', getUserProfile);

module.exports = router;

'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.createTable('Payments', {
        id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
        },
        userId: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
            model: 'Users',
            key: 'id'
        }
        },
        bookingId: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
            model: 'Bookings',
            key: 'id'
        }
        },
        amount: {
        type: Sequelize.DECIMAL(10, 2),
        allowNull: false
        },
        paymentMethod: {
        type: Sequelize.ENUM('card','upi','netbanking','wallet','cash'),
        allowNull: false // e.g., credit card, PayPal
        },
        paymentStatus: {
        type: Sequelize.ENUM('pending', 'completed', 'failed'),
        allowNull: false,
        defaultValue: 'pending' // e.g., pending, completed, failed
        },
        transactionId: {
        type: Sequelize.STRING,
        allowNull: false
        },
        paidAt: {
        type: Sequelize.DATE,
        defaultValue: Sequelize.NOW
        }
    })
  },

  async down (queryInterface, Sequelize) {
    /**
     * Add reverting commands here.
     *
     * Example:
     * await queryInterface.dropTable('users');
     */
  }
};

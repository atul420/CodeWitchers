module.exports = (sequelize, DataTypes) => {
  const Bookings = sequelize.define('Bookings', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    userId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'Users',
        key: 'id'
      }
    },
    eventId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'Events',
        key: 'id'
      }
    },
    locationId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'Locations',
        key: 'id'
      }
    },
    numberOfTickets: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    totalPrice: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: false
    },
    bookedAt: {
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW
    },
    status: {
      type: DataTypes.ENUM('pending', 'confirmed', 'cancelled'),
      allowNull: false,
      defaultValue: 'pending' // e.g., pending, confirmed, cancelled
    }
  });

  Bookings.associate = (models) => {
    Bookings.belongsTo(models.Users, { foreignKey: 'userId' });
    Bookings.belongsTo(models.Events, { foreignKey: 'eventId' });
    Bookings.belongsTo(models.Locations, { foreignKey: 'locationId' });
    Bookings.hasOne(models.Payments, { foreignKey: 'bookingId' }); // Optional, but common
  };

  return Bookings;
};
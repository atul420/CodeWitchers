module.exports = (sequelize, DataTypes) => {
  const EventLocations = sequelize.define('EventLocations', {
    eventId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      references: {
        model: 'Events',
        key: 'id'
      }
    },
    locationId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      references: {
        model: 'Locations',
        key: 'id'
      }
    }
  }, {
    tableName: 'EventLocations',
    timestamps: false
  });

  EventLocations.associate = (models) => {
    EventLocations.belongsTo(models.Events, { foreignKey: 'eventId' });
    EventLocations.belongsTo(models.Locations, { foreignKey: 'locationId' });
  };

  return EventLocations;
}

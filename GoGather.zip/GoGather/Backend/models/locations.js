
module.exports=(sequelize, DataTypes) => {
  const Locations = sequelize.define('Locations', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    building: {
      type: DataTypes.STRING,
      allowNull: false
    },
    city: {
      type: DataTypes.STRING,
      allowNull: false
    },
    state: {
      type: DataTypes.STRING,
      allowNull: false
    },
    country: {
      type: DataTypes.STRING,
      allowNull: false
    },
    postalCode: {
      type: DataTypes.STRING,
      allowNull: false
    }
  });

  Locations.associate = (models) => {
    Locations.belongsToMany(models.Events, {
        through: 'event_locations',
        foreignKey: 'locationId',
        otherKey: 'eventId'
    });
    Locations.hasMany(models.Bookings, { foreignKey: 'locationId' });
    };

  return Locations;
}
module.exports = (sequelize, DataTypes)=>{
    const Payments = sequelize.define('Payments', {
        id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
        },
        userId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'Users',
            key: 'id'
        }
        },
        bookingId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'Bookings',
            key: 'id'
        }
        },
        amount: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
        },
        paymentMethod: {
        type: DataTypes.ENUM('card','upi','netbanking','wallet','cash'),
        allowNull: false // e.g., credit card, PayPal
        },
        paymentStatus: {
        type: DataTypes.ENUM('pending', 'completed', 'failed'),
        allowNull: false,
        defaultValue: 'pending' // e.g., pending, completed, failed
        },
        transactionId: {
        type: DataTypes.STRING,
        allowNull: false
        },
        paidAt: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
        }
    });

    Payments.associate = (models) => {
        Payments.belongsTo(models.Users, { foreignKey: 'userId' });
        Payments.belongsTo(models.Bookings, { foreignKey: 'bookingId' });
    };

    return Payments;
}
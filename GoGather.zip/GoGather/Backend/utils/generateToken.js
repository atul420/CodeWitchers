const jwt = require('jsonwebtoken');

const generateToken = (user) => {
  const payload = {
    id: user.id,
    username: user.username,
    email: user.email,
    role: user.role
  };

  const secretKey = process.env.JWT_SECRET || 'defaultSecretKey';
  const options = {
    expiresIn: '7d' // Token expiration time
  };

  return jwt.sign(payload, secretKey, options);
};

module.exports = generateToken;